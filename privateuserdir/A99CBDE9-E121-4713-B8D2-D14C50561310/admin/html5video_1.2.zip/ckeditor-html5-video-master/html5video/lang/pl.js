CKEDITOR.plugins.setLang( 'html5video', 'pl', {
    button: 'Wstaw HTML5 video',
    title: 'HTML5 video',
    infoLabel: 'Informacje',
    allowed: 'Dozwolone typy plików: MP4, WebM, Ogv',
    urlMissing: 'Nie znaleziono URL do pliku video.',
    videoProperties: 'Właściwości',
    upload: 'Wrzuć plik',
    btnUpload: 'Wyślij na serwer',
    advanced: 'Zaawansowane',
    autoplay: 'Autoodtwarzanie?',
    allowdownload: 'Allow download?',
    advisorytitle: 'Advisory title',
    yes: 'Tak',
    no: 'Nie',
    responsive: 'Szerokość responsywna',
    controls: 'Pokaż kontrolki'
} );
